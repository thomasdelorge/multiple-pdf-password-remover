# Multiple pdf password remover

## Description
A really simple script to remove (not crack !) password from multiple pdf files.

Available in two versions :

## Powershell (NEW !)
(+) Support multiple passwords possibilities

(+) Two level of logs : debug & succeeded only

(+) Auto-detect & Download qPDF from Github repo

(-) Probably windows only cause of using Windows Forms

## Python (console only)
(+) Python : welcome linux's friends

(-) Console only

(-) Need edit script before launch (set password)

(-) Some dependencies
