# Multiple pdf password remover - Powershell

## Description
Enhanced python version with GUI and multi-password tester.

## Dependencies
This script was created and tested only in Win11 : GUI use Windows.Forms !

## Usage
1) Download Start-BulkRemovePdfPassword.ps1 and launch it !

## Warning
This script will search PDF into all subdirectories !

## Screenshots
![alt text](https://github.com/thomasdelorge/multiple-pdf-password-remover/blob/main/powershell/screenshot.jpg?raw=true "powershell gui")
